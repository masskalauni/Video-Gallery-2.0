# Category Filter #
This jQuery plugin will filter content on a page based on a category.

View the [demo](https://kenthhagstrom.se/bs4a6jquery-cat-filter-demo/), which is built with Bootstrap 4 Alpha 6.

### Usage ###
I will add instructions shortly, for now you'll have to figure things out yourself, check out the [demo](https://kenthhagstrom.se/bs4a6jquery-cat-filter-demo/) site!

## Contribute ##
This is my FIRST jQuery plugin EVER, so if you have any suggestions, please help me improve my code! If you do send me a pull request, please explain what your changes does thoroughly.

Anyone is welcome to contribute to this script. There are various ways you can contribute:

- Raise an [Issue](https://github.com/kenthhagstrom/Category-Filter/issues/new)
- Send a Pull Request with your bug fixes and/or new features
- Provide feedback and suggestions